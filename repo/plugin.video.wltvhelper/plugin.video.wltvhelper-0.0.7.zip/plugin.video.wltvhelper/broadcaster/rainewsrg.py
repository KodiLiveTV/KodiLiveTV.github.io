# -*- coding: utf-8 -*-

import requests, scrapers, config
host = 'https://www.rainews.it'

def play(search):
    res = []
    url = ''
    pageUrl = '{}/tgr/{}/notiziari/index.html?/tgr/rainews.html'.format(host, search)
    data = requests.get(pageUrl).text
    url = scrapers.find_single_match(data, r'data-mediaurl="(.*?)"')

    if url:
        res = [url]

    return res