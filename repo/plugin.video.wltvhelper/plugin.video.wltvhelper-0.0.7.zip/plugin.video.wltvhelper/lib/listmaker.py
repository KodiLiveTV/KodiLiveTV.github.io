# -*- coding: utf-8 -*-
import xbmc, xbmcgui, requests, config, logger, base64, json

res = requests.get('http://tvchannels.worldlivetv.eu/tv/m3us.json').json()
activeLists = [l['Name'] for l in res if l['Enabled']]

groups = []
for list in activeLists:
    res = requests.get('http://tvchannels.worldlivetv.eu/tv/{}/groups.json'.format(list)).json()
    groups += [[g['id'], g['count'], list] for g in res]



LIST = 1
OK = 2
CLOSE = 3
LEFT = 1
RIGHT = 2
UP = 3
DOWN = 4
EXIT = 10
BACKSPACE = 92

class ListMaker(xbmcgui.WindowXMLDialog):
    def __init__(self, *args):
        self.doModal()

    def onInit(self):
        self.List = self.getControl(LIST)
        item = xbmcgui.ListItem('+')
        item.setProperty('listurl','')
        settings = config.getSetting('list')
        self.list = []
        if settings:
            settings = json.loads(base64.b64decode(settings))
            try:
                for setting in settings:
                    item = xbmcgui.ListItem(setting['Name'])
                    item.setProperty('listurl',setting['UrlList'])
                    item.setProperty('preselected',','.join([str(g) for g in setting['preselected']]))
                    self.list.append(item)
            except:
                config.setSetting('list','')

        self.list.append(xbmcgui.ListItem('+'))
        self.List.reset()
        self.List.addItems(self.list)
        self.setFocusId(LIST)
        self.List.selectItem(0)

    def onClick(self, control):
        logger.debug(control)
        if control == LIST:
            selection = self.List.getSelectedItem()
            grouplist = ['{} [{}]'.format(g[0], g[1]) for g in groups]
            if selection.getLabel() == '+':
                selected = xbmcgui.Dialog().multiselect('Seleziona i gruppi', grouplist)
                if selected:
                    url = 'http://tvchannels.worldlivetv.eu/tv/rebrandly/list.m3u?groups=' + ','.join([groups[g][0] for g in selected])
                    name = xbmcgui.Dialog().input('Nome della Lista')
                    if not name: name = 'Lista {}'.format(len(self.list))
                    item = xbmcgui.ListItem(name)
                    item.setProperty('listurl',url)
                    item.setProperty('preselected',','.join([str(g) for g in selected]))
                    self.list.insert(-1, item)
                    self.List.reset()
                    self.List.addItems(self.list)
                    self.setFocusId(LIST)
                    self.List.selectItem(len(self.list) - 1)
            else:
                pos = self.List.getSelectedPosition()
                self.list.pop(pos)
                preselected = [int(i) for i in selection.getProperty('preselected').split(',')]
                selected = xbmcgui.Dialog().multiselect('Seleziona i gruppi', grouplist, preselect=preselected)
                if selected:
                    url = 'http://tvchannels.worldlivetv.eu/tv/rebrandly/list.m3u?groups=' + ','.join([groups[g][0] for g in selected])
                    name = xbmcgui.Dialog().input('Nome della Lista', selection.getLabel())
                    item = xbmcgui.ListItem(name)
                    item.setProperty('listurl',url)
                    item.setProperty('preselected',','.join([str(g) for g in selected]))
                    self.list.insert(pos, item)
                self.List.reset()
                self.List.addItems(self.list)
                self.setFocusId(LIST)
                self.List.selectItem(pos)
        elif control == OK and len(self.list) > 1:
            lists = []
            for item in self.list:
                if item.getLabel() != '+':
                    lists.append({'Name':item.getLabel(), 'UrlList':item.getProperty('listurl'), "UrlEPG":"http://epg-guide.com/kltv.gz", 'preselected':[int(i) for i in item.getProperty('preselected').split(',')]})
            config.setSetting('list', base64.b64encode(json.dumps(lists)))
            self.exit()

        elif control == CLOSE:
            self.exit()

    def onAction(self, action):
        action = action.getId()
        if action in [EXIT, BACKSPACE]:
            self.exit()

    def exit(self):
        self.close()

if groups:
    ListMaker('ListMaker.xml', config.ADDONPATH, 'Default')

