# -*- coding: utf-8 -*-

import requests

def play(search):
    res=[]
    url=''
    requrl = 'https://raiplay.it/dirette.json'
    json = requests.get(requrl).json()['contents']
    for key in json:
        channel = key['channel']
        if search == channel:
            url = key['video']['content_url']
    if url: res = [url]
    return res