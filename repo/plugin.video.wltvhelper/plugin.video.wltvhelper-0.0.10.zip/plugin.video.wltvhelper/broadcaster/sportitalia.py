# -*- coding: utf-8 -*-

import requests

#PLAYER_URL = 'https://www.sportitalia.com/it-int/playerpage/'
BASE_URL = 'https://www.sportitalia.com/api/v2/content/{}/access'
CHANNELS = {
    'sihd': 57561,
    'calcio': 57564,
    'motori': 57568,
    'live24': 57570
}

def play(search):
    url = ''
    if search in CHANNELS:
        requrl = BASE_URL.format(CHANNELS[search])
        jsonres = requests.post(requrl).json()
        url = jsonres['data']['stream']

    return [url]
