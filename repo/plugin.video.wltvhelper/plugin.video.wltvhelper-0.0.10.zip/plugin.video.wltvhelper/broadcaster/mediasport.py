# -*- coding: utf-8 -*-

import requests
from lib import scrapers, logger

api = 'https://platform.wim.tv/wimtv-server'
headers = {
    'Content-Type': 'application/json', #'application/x-www-form-urlencoded; charset=UTF-8',
    'User-Agent': 'Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
    'Referer': 'https://platform.wim.tv/','X-Requested-With': 'XMLHttpRequest'
}
session = requests.Session()
session.headers.update(headers)

def play(search):
    logger.debug()
    res = []

    if search == 'extra':
        pageUrl = 'https://mschannel.tv/extra'
    else:
        pageUrl = 'https://{}.tv'.format(search)

    data = session.get(pageUrl).text

    match = scrapers.find_single_match(data, r'iframe.*?src\s*="[^\?]+\?(\w+)=([^&]+)')

    if match:
        channelType, channelId = match
        logger.debug('channelType:', channelType, 'channelId:', channelId)

        query = { 'grant_type':'client_credentials' }
        token = session.post('{}/oauth/token'.format(api), auth=requests.auth.HTTPBasicAuth('www', ''), params=query).json().get('access_token','')

        session.headers.update({'Authorization': 'Bearer {}'.format(token), 'Origin': 'https://platform.wim.tv'})
        _json = session.post('{}/api/public/{}/channel/{}/play'.format(api,channelType,channelId), json={}).json().get('srcs', [])

        for item in _json:
            if item['mimeType'] == 'application/x-mpegurl':
                url = item['uniqueStreamer']
                res = [url]
                break

    return res