# -*- coding: utf-8 -*-

import requests, scrapers, logger, json
from requests.auth import HTTPBasicAuth

api = 'https://platform.wim.tv/wimtv-server'
msHeaders = {
    'Content-Type': 'application/json', #'application/x-www-form-urlencoded; charset=UTF-8',
    'User-Agent': 'Mozilla/50.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
    'Referer': 'https://platform.wim.tv/','X-Requested-With': 'XMLHttpRequest'
}

def play(search):
    res = []
    url = ''
    channelType = ''
    channelId = ''

    session = requests.Session()
    pageUrl = 'https://{}.tv'.format(search)

    if (search=='extra'):
        pageUrl = 'https://mschannel.tv/extra'
        
    data = requests.get(pageUrl).text

    rexChId='<iframe.*?src=.*?\=([^\"]+)\&'
    channelId = scrapers.find_single_match(data, rexChId)

    rexChType='<iframe.*?src=.*?\?(\w+)'
    channelType = scrapers.find_single_match(data, rexChType)
    
    #logger.info('channelId :=> ' + channelId )
    #logger.info('channelType :=> ' + channelType )
    
    query = { 'grant_type':'client_credentials' }
    _json = session.post('{}/oauth/token'.format(api),auth=HTTPBasicAuth('www', ''), params=query, headers=msHeaders).json()
    token = _json['access_token']

    session = requests.Session()
    session.headers.update({'Authorization': 'Bearer {}'.format(token), 'Origin': 'https://platform.wim.tv'})
    _json = session.post('{}/api/public/{}/channel/{}/play'.format(api,channelType,channelId), json={}, headers=msHeaders).json()

    for item in _json['srcs']:
        if item['mimeType'] == 'application/x-mpegurl':
            url = item['uniqueStreamer']
            res = [url]
            break

    return res