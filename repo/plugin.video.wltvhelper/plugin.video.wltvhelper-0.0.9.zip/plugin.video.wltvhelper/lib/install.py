# -*- coding: utf-8 -*-

import xbmcgui, xbmc, os, sys, socket, time
from lib import requests, logger, config

if sys.version_info[0] >= 3:
    import xbmcvfs
    from xbmcvfs import translatePath
else:
    from xbmc import translatePath

from xbmcaddon import Addon
import traceback
dialog = xbmcgui.Dialog()

if sys.version_info[0] >= 3:
    VFS = False
    PY3 = True
    import urllib.request as urllib
else:
    VFS = True
    PY3 = False
    import urllib2 as urllib

xbmc_vfs = True                                                 # False to disable XbmcVFS, True to enable
if xbmc_vfs:
    try:
        import xbmcvfs
        if not PY3:
            sys.setdefaultencoding('utf-8')                     # xbmcvfs demeans the value of defaultencoding. It is reestablished
        xbmc_vfs = True
    except:
        xbmc_vfs = False


def tempfile(filename):
    return translatePath(os.path.join("special://temp/", filename))

def install():
    install_inputstream()
    install_widevine()


def install_web_pdb():
    if not os.path.exists(translatePath('special://home/addons/script.module.web-pdb')) and not os.path.exists(translatePath('special://xbmcbinaddons/script.module.web-pdb')):
        xbmc.executebuiltin('InstallAddon(script.module.web-pdb)', wait=True)
        try:
            webpdb = Addon(id='script.module.web-pdb')
        except:
            pass
            # TODO Show dialog?

    try:
        # Check if it's active
        webpdb = Addon(id='script.module.web-pdb')
    except:
        # if it's not active ask to activate it
        if xbmcgui.Dialog().yesno(config.getString(30000), config.getString(30111)):
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "script.module.web-pdb", "enabled": true }}')
            webpdb = Addon(id='script.module.web-pdb')

    bottle = Addon(id='script.module.bottle')
    return config.translatePath(os.path.join(webpdb.getAddonInfo('Path'), 'libs')), config.translatePath(os.path.join(bottle.getAddonInfo('Path'), 'lib'))


def install_pvr():
    # Check if PVR Simple Client is installed
    # if it doesn't exist, ask to install it.

    simple = None

    if not os.path.exists(translatePath('special://home/addons/pvr.iptvsimple')) and not os.path.exists(translatePath('special://xbmcbinaddons/pvr.iptvsimple')):
        xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)', wait=True)
        try:
            simple = Addon(id='pvr.iptvsimple')
        except:
            pass
            # TODO Show dialog?

    try:
        # Check if it's active
        simple = Addon(id='pvr.iptvsimple')
    except:
        # if it's not active ask to activate it
        if xbmcgui.Dialog().yesno(config.getString(30000), config.getString(30111)):
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": true }}')
            simple = Addon(id='pvr.iptvsimple')

    return simple


def install_inputstream():
    if not os.path.exists(os.path.join(translatePath('special://home/addons/'),'inputstream.adaptive')) and not os.path.exists(os.path.join(translatePath('special://xbmcbinaddons/'),'inputstream.adaptive')):
        try:
            # See if there's an installed repo that has it
            xbmc.executebuiltin('InstallAddon(inputstream.adaptive)', wait=True)

            # Check if InputStream add-on exists!
            Addon('inputstream.adaptive')

            logger.debug('InputStream add-on installed from repo.')
        except RuntimeError:
            logger.debug('InputStream add-on not installed.')
            dialog.ok(config.getString(30100), config.getString(30101))
            return False
    else:
        try:
            Addon('inputstream.adaptive')
            logger.debug('InputStream add-on is installed and enabled')
        except:
            logger.debug('enabling InputStream add-on')
            xbmc.executebuiltin('UpdateLocalAddons')
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "inputstream.adaptive", "enabled": true }}')
    return True


def install_widevine():
    platform = get_platform()
    if platform['os'] != 'android':
        from xbmcaddon import Addon
        import json
        from distutils.version import LooseVersion
        path = translatePath(Addon('inputstream.adaptive').getSetting('DECRYPTERPATH'))

        # if Widevine CDM is not installed
        if not os.path.exists(path) or not os.listdir(path):
            select = dialog.yesno(config.getString(30102), config.getString(30103))
            # select = dialog.yesno('Widevine CDM', "Alcuni contenuti hanno bisogno di Widevine CDM per essere visualizzati. Vuoi installarlo?")
            if select > 0:
                if not 'arm' in platform['arch']:
                    last_version = requests.get('https://dl.google.com/widevine-cdm/versions.txt').text.split()[-1]
                    download_widevine(last_version, platform, path)
                else:
                    devices = requests.get('https://dl.google.com/dl/edgedl/chromeos/recovery/recovery.json').json()
                    download_chromeos_image(devices, platform, path)

        # if Widevine CDM is outdated
        elif platform['os'] != 'android':
            if not 'arm' in platform['arch']:
                last_version = requests.get('https://dl.google.com/widevine-cdm/versions.txt').text.split()[-1]
                current_version = json.loads(open(os.path.join(path, 'manifest.json')).read())['version']
                if LooseVersion(last_version) > LooseVersion(current_version):
                    select = dialog.yesno(config.getString(30104), config.getString(30105))
                    if select > 0: download_widevine(last_version, platform, path)
            else:
                devices = requests.get('https://dl.google.com/dl/edgedl/chromeos/recovery/recovery.json').json()
                current_version = json.loads(open(os.path.join(path, 'config.json')).read())['version']
                last_version = best_chromeos_image(devices)['version']
                if LooseVersion(last_version) > LooseVersion(current_version):
                    select = dialog.yesno(config.getString(30104), config.getString(30105))
                    if select > 0:download_chromeos_image(devices, platform, path)


def download_widevine(version, platform, path):
    # for x86 architectures
    from zipfile import ZipFile
    archiveName = 'https://dl.google.com/widevine-cdm/' + version + '-' + platform['os'] + '-' + platform['arch'] + '.zip'
    fileName = tempfile('widevine.zip')
    if not os.path.exists(archiveName):
        if not os.path.exists(fileName):
            downloadfile(archiveName, fileName, 'Download Widevine CDM')
        zip_obj = ZipFile(fileName)
        for filename in zip_obj.namelist():
            zip_obj.extract(filename, path)
        zip_obj.close()
        os.remove(fileName)


def download_chromeos_image(devices, platform, path):
    # for arm architectures
    from core import jsontools
    best = best_chromeos_image(devices)
    archiveName = best['url']
    version = best['version']

    fileName = tempfile(archiveName.split('/')[-1])
    if not os.path.exists(fileName):
        downloadfile(archiveName, fileName, 'Download Widevine CDM')
    from lib.arm_chromeos import ChromeOSImage
    progress = xbmcgui.DialogProgress()
    progress.create(config.getString(30106), config.getString(30107))
    ChromeOSImage(fileName).extract_file(
                filename='libwidevinecdm.so',
                extract_path=os.path.join(path),
                progress=progress)
    recovery_file = os.path.join(path, os.path.basename('https://dl.google.com/dl/edgedl/chromeos/recovery/recovery.json'))
    config_file = os.path.join(path, 'config.json')
    if not os.path.exists(path):
        os.mkdir(path)
    with open(recovery_file, 'wb') as reco_file:
        reco_file.write(jsontools.dump(devices, indent=4))
        reco_file.close()
    with open(config_file, 'wb') as conf_file:
        conf_file.write(jsontools.dump(best))
        conf_file.close()
    os.remove(fileName)

def best_chromeos_image(devices):
    best = None
    for device in devices:
        # Select ARM hardware only
        for arm_hwid in ['BIG','BLAZE','BOB','DRUWL','DUMO','ELM','EXPRESSO','FIEVEL','HANA','JAQ','JERRY','KEVIN','KITTY','MICKEY','MIGHTY','MINNIE','PHASER','PHASER360','PI','PIT','RELM','SCARLET','SKATE','SNOW','SPEEDY','SPRING','TIGER']:
            if arm_hwid in device['hwidmatch']:
                hwid = arm_hwid
                break  # We found an ARM device, rejoice !
        else:
            continue  # Not ARM, skip this device

        device['hwid'] = hwid

        # Select the first ARM device
        if best is None:
            best = device
            continue  # Go to the next device

        # Skip identical hwid
        if hwid == best['hwid']:
            continue

        # Select the newest version
        from distutils.version import LooseVersion  # pylint: disable=import-error,no-name-in-module,useless-suppression
        if LooseVersion(device['version']) > LooseVersion(best['version']):
            logger.debug('%s (%s) is newer than %s (%s)' % (device['hwid'], device['version'], best['hwid'], best['version']))
            best = device

        # Select the smallest image (disk space requirement)
        elif LooseVersion(device['version']) == LooseVersion(best['version']):
            if int(device['filesize']) + int(device['zipfilesize']) < int(best['filesize']) + int(best['zipfilesize']):
                logger.debug('%s (%d) is smaller than %s (%d)' % (device['hwid'], int(device['filesize']) + int(device['zipfilesize']), best['hwid'], int(best['filesize']) + int(best['zipfilesize'])))
                best = device
    return best

def get_platform():
    import platform
    build = xbmc.getInfoLabel("System.BuildVersion")
    kodi_version = int(build.split()[0][:2])
    ret = {
        "auto_arch": sys.maxsize > 2 ** 32 and "64-bit" or "32-bit",
        "arch": sys.maxsize > 2 ** 32 and "x64" or "ia32",
        "os": "",
        "version": platform.release(),
        "kodi": kodi_version,
        "build": build
    }
    if xbmc.getCondVisibility("system.platform.android"):
        ret["os"] = "android"
        if "arm" in platform.machine() or "aarch" in platform.machine():
            ret["arch"] = "arm"
            if "64" in platform.machine() and ret["auto_arch"] == "64-bit":
                ret["arch"] = "arm64"
    elif xbmc.getCondVisibility("system.platform.linux"):
        ret["os"] = "linux"
        if "aarch" in platform.machine() or "arm64" in platform.machine():
            if xbmc.getCondVisibility("system.platform.linux.raspberrypi"):
                ret["arch"] = "armv7"
            elif ret["auto_arch"] == "32-bit":
                ret["arch"] = "armv7"
            elif ret["auto_arch"] == "64-bit":
                ret["arch"] = "arm64"
            elif platform.architecture()[0].startswith("32"):
                ret["arch"] = "arm"
            else:
                ret["arch"] = "arm64"
        elif "armv7" in platform.machine():
            ret["arch"] = "armv7"
        elif "arm" in platform.machine():
            ret["arch"] = "arm"
    elif xbmc.getCondVisibility("system.platform.xbox"):
        ret["os"] = "win"
        ret["arch"] = "x64"
    elif xbmc.getCondVisibility("system.platform.windows"):
        ret["os"] = "win"
        if platform.machine().endswith('64'):
            ret["arch"] = "x64"
    elif xbmc.getCondVisibility("system.platform.osx"):
        ret["os"] = "mac"
        ret["arch"] = "x64"
    elif xbmc.getCondVisibility("system.platform.ios"):
        ret["os"] = "ios"
        ret["arch"] = "arm"

    return ret


def downloadfile(url, filename, header=''):
    logger.debug("url= " + url)
    logger.debug("filename= " + filename)

    progress = None

    filename = translatePath(filename)

    try:
        try:
            filename = xbmc.makeLegalFilename(filename)
        except:
            pass
        logger.debug("filename= " + filename)

        # The file exists and you want to continue
        if os.path.exists(filename):
            f = file_open(filename, 'r+b', vfs=VFS)
            ExistSize = 0
            grabbed = 0

        # the file does not exist
        else:
            ExistSize = 0
            logger.debug("the file does not exist")

            f = file_open(filename, 'wb', vfs=VFS)
            grabbed = 0

        # Create the progress dialog
        progress = xbmcgui.DialogProgress()
        progress.create(header, "Downloading..." + '\n' + url + '\n' + filename)

        # Socket timeout at 60 seconds
        socket.setdefaulttimeout(60)

        h = urllib.HTTPHandler(debuglevel=0)
        request = urllib.Request(url)

        if ExistSize > 0:
            request.add_header('Range', 'bytes= %d-' % (ExistSize,))

        opener = urllib.build_opener(h)
        urllib.install_opener(opener)
        try:
            connexion = opener.open(request)
        except urllib.error.HTTPError as e:
            logger.error("error %d (%s) opening url %s" % (e.code, e.msg, url))
            f.close()
            progress.close()
            # Error 416 is that the requested range is greater than the file => is that it is already complete
            if e.code == 416:
                return 0
            else:
                return -2

        try:
            totalFileSize = int(connexion.headers["Content-Length"])
        except ValueError:
            totalFileSize = 1

        if ExistSize > 0:
            totalFileSize = totalFileSize + ExistSize

        logger.debug("Content-Length= %s" % totalFileSize)

        blocksize = 100 * 1024

        readBlock = connexion.read(blocksize)
        logger.debug("Starting downloading the file, blocked= %s" % len(readBlock))

        maxretries  = 10

        while len(readBlock) > 0:
            try:
                # Write the block read
                f.write(readBlock)
                grabbed += len(readBlock)
                percent = int(float(grabbed) * 100 / float(totalFileSize))
                totalmb = float(float(totalFileSize) / (1024 * 1024))
                downloadedsmb = float(float(grabbed) / (1024 * 1024))

                # Read the next block, retrying not to stop everything at the first timeout
                retries  = 0
                while retries  <= maxretries :
                    try:
                        before = time.time()
                        readBlock = connexion.read(blocksize)
                        after = time.time()
                        if (after - before) > 0:
                            speed = old_div(len(readBlock), (after - before))
                            falta = totalFileSize - grabbed
                            if speed > 0:
                                missingTime = old_div(falta, speed)
                            else:
                                missingTime = 0
                            # logger.debug(sec_to_hms(missingTime))
                            progress.update(percent, "%.2fMB/%.2fMB (%d%%) %.2f Kb/s %s" % (downloadedsmb, totalmb, percent, old_div(speed, 1024), sec_to_hms(missingTime)))
                        break
                    except:
                        retries  += 1
                        logger.debug("ERROR in block download, retry %d" % retries )
                        import traceback
                        logger.error(traceback.print_exc())
                
                # The user cancels the download
                try:
                    if progress.iscanceled():
                        logger.debug("Download of file canceled")
                        f.close()
                        progress.close()
                        return -1
                except:
                    pass

                # There was an error in the download
                if retries  > maxretries :
                    logger.debug("ERROR in the file download")
                    f.close()
                    progress.close()

                    return -2

            except:
                import traceback
                logger.error(traceback.print_exc())

                f.close()
                progress.close()

                return -2

    except:
        import traceback
        from pprint import pprint
        exc_type, exc_value, exc_tb = sys.exc_info()
        lines = traceback.format_exception(exc_type, exc_value, exc_tb)
        for line in lines:
            line_splits = line.split("\n")
            for line_split in line_splits:
                logger.error(line_split)

    try:
        f.close()
    except:
        pass

    try:
        progress.close()
    except:
        pass

    logger.debug("End of file download")


def file_open(path, mode="r", silent=False, vfs=True):
    """
    Open a file
    @param path: path
    @type path: str
    @rtype: str
    @return: file object
    """
    try:
        if xbmc_vfs and vfs:
            if 'r' in mode and '+' in mode:
                mode = mode.replace('r', 'w').replace('+', '')
                logger.debug('Open MODE changed to: %s' % mode)
            if 'a' in mode:
                mode = mode.replace('a', 'w').replace('+', '')
                logger.debug('Open MODE changed to: %s' % mode)
            return xbmcvfs.File(path, mode)
        else:
           return open(path, mode)
    except:
        logger.error("ERROR when opening file: %s, %s" % (path, mode))
        if not silent:
            logger.error(traceback.format_exc())
        return False

def old_div(a, b):
    import numbers
    """
    Equivalent to ``a / b`` on Python 2 without ``from __future__ import
    division``.

    TODO: generalize this to other objects (like arrays etc.)
    """
    if isinstance(a, numbers.Integral) and isinstance(b, numbers.Integral):
        return a // b
    else:
        return a / b

__all__ = ['PY3', 'PY2', 'PYPY', 'with_metaclass', 'native', 'old_div']


def sec_to_hms(seconds):
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return "%02d:%02d:%02d" % (h, m, s)