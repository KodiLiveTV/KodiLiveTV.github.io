# -*- coding: utf-8 -*-

import xbmcaddon, logger
addon = xbmcaddon.Addon(id='plugin.video.wltvhelper')

def getSetting(name):
    value = addon.getSetting(name)
    if value == "true":
        return True
    elif value == "false":
        return False
    else:
        return value

def openSetting():
    addon.openSettings()

def getAddonInfo(name):
    return addon.getAddonInfo(name)

def quality(qualities):
    resolutions = [1080, 720, 480]
    resolution = resolutions[int(getSetting('resolutions'))]
    selected = [min(range(len(qualities)), key = lambda i: abs(int(qualities[i])-resolution))][0]
    return selected