# -*- coding: utf-8 -*-

import requests
def play(search):
    res=[]
    url=''
    requrl = 'https://raiplay.it/dl/RaiPlay/2016/PublishingBlock-9a2ff311-fcf0-4539-8f8f-c4fee2a71d58.html?json'
    json = requests.get(requrl).json()['dirette']
    for key in json:
        channel = key['channel']
        if search == channel:
            url = key['video']['contentUrl']
    if url: res = [url]
    return res