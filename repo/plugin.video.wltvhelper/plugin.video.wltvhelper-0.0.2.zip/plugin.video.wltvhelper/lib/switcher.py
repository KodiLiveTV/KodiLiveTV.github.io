# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcaddon, config, logger, base64, json
try:
    simple = xbmcaddon.Addon(id='pvr.iptvsimple')
    addon = config.ADDON
    addonpath = xbmc.translatePath(addon.getAddonInfo('Path'))

    from datetime import date
    today = date.today().strftime("%d/%m/%Y")
    if today != config.getSetting('lastcheck'):
        import requests
        res = requests.get('http://www.worldlivetv.eu/testb64.txt').text
        config.setSetting('list', res)
        config.setSetting('lastcheck', today)
        data = json.loads(base64.b64decode(res))
    else:
        data = json.loads(base64.b64decode(config.getSetting('list')))


    LIST = 1
    CLOSE = 2
    SETTING = 3
    LEFT = 1
    RIGHT = 2
    UP = 3
    DOWN = 4
    EXIT = 10
    BACKSPACE = 92


    class ListSelection(xbmcgui.WindowXMLDialog):
        def __init__(self, *args):
            self.preselected = config.getSetting('selected')
            self.doModal()
        def onInit(self):
            self.preselected = config.getSetting('selected')
            self.List = self.getControl(LIST)

            self.list = [xbmcgui.ListItem(key['Name']) for key in data]
            self.List.reset()
            self.List.addItems(self.list)
            self.setFocusId(LIST)
            self.List.selectItem(self.preselected )

        def onClick(self, control):
            if control == LIST:
                selection = self.List.getSelectedPosition()
                config.setSetting('selected', selection)
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": false }}')
                simple.setSetting('m3uPathType', '1')
                simple.setSetting('epgPathType', '1')
                simple.setSetting('m3uUrl', data[selection]['UrlList'])
                simple.setSetting('epgUrl', data[selection]['UrlEPG'])
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": true }}')
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": false }}')
                xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.iptvsimple", "enabled": true }}')
                self.exit()
            elif control == CLOSE:
                self.exit()
            elif control == SETTING:
                addon.openSettings()

        def onAction(self, action):
            action = action.getId()
            if action in [EXIT, BACKSPACE, LEFT]:
                self.exit()

        def exit(self):
            self.close()

    ListSelection('ListSelection.xml', addonpath, 'Default')
except:
    xbmcgui.Dialog().ok(config.getString(30000), config.getString(30108))
