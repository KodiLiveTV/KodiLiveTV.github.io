# -*- coding: utf-8 -*-

from lib import requests
def play(search):
    channels = {'Sky TG24':1, 'Cielo':2, 'TV8':7}
    url = ''
    if search in channels:
        requrl = 'https://apid.sky.it/vdp/v1/getLivestream?id={}&isMobile=false'.format(channels[search])
        url = requests.get(requrl).json()['streaming_url']
    return [url]